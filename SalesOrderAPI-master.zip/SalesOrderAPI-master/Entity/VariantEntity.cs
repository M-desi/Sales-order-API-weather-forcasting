public class VariantEntity{
     public int Id { get; set; }
        public string? VarintName { get; set; }
        public string? VarinatType { get; set; }
        public bool? IsActive { get; set; }
}