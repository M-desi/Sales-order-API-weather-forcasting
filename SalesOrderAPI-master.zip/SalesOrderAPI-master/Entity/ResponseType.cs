public class ResponseType{
    public string? Result{get;set;}
     public string? KyValue{get;set;}
}