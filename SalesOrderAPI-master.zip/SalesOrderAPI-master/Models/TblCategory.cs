﻿using System;
using System.Collections.Generic;

namespace SalesOrderAPI.Models
{
    public partial class TblCategory
    {
        public int Id { get; set; }
        public string? Name { get; set; }
    }
}
