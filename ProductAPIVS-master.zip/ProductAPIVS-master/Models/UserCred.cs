public class UserCred
{
    public string? username { get; set; }
    public string? password { get; set; }
}